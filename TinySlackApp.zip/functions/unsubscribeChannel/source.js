exports = function(arg){
  const channelName = arg.channelName;
    
    var collection = context.services.get("mongodb-atlas").db("tinyslack").collection("users");

    return collection.updateOne({userId: context.user.id}, {'$pull': {"channels": {"channelId": channelName}}}).then(r => {
      return r;
    }).catch((err) => {
      return err;
    });
};