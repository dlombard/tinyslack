exports = function(arg){
    //let arg = { channelName: "Watercooler", user: "Jason", message: "Where's the water?"};
    let channel = arg.channelName;
    let username = arg.user;
    let message = arg.message;
    
    if (!channel)
      return { success: false, message: "No channel name specified." };
    if (!message)
      return { success: false, message: "Message not specified." };

    const mongodb = context.services.get("mongodb-atlas");
    
    const dbname = context.values.get("DATABASE_NAME");
    const collection = mongodb.db(dbname).collection("messages");

    return collection
    .deleteOne({channelname: channel, username: context.user.id , message: message})
    .then(result => {
      const { deletedId } = result;
      console.log("Deleted message Id " + deletedId);
      return { success: true, message: "Message successfully deleted" };
   });
  
};