exports = function(arg){
  const channelName = arg.channelName;
  
  if (!channelName)
    return { success: false, message: "Channel name required" };
    
  
  const currentUser = context.functions.execute("getCurrentUser");
  
  const mongodb = context.services.get("mongodb-atlas");
  const dbname = context.values.get("DATABASE_NAME");
  const collection = mongodb.db(dbname).collection("messages");
  
  return collection.find({ channelName: channelName }).sort({ _id: -1 }).limit(50).toArray();
};