exports = async (arg) => {
  const {channelId} = arg;
  console.log(channelId)
  
  if (!channelId)
    return { success: false, message: "Channel not found" };
    
  try {
  const currentUser = await context.functions.execute("getCurrentUser");
  const mongodb = context.services.get("mongodb-atlas");
  const dbname = context.values.get("DATABASE_NAME");
  const collection = mongodb.db(dbname).collection("messages");
  
  return await collection.find({channelId}, {username: 1, message: 1, _id: 1}).sort({_id: -1}).limit(50).toArray()
    
  }
  catch(e){
    return e;
  }
};