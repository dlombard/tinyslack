exports = function(arg){

    var collection = context.services.get("mongodb-atlas").db("tinyslack").collection("users");
    return collection.updateOne({userId: context.user.id}, {'$set': {"displayName": arg.displayName}}).then(r => {
      console.log(r);
      return r;
    }).catch(e => {
      return e;
    }); 

    
};