exports = function(arg){
  
    var displayName = context.user.data.email;
    if(arg.displayName){
      displayName = arg.displayName;
    }
   var collection = context.services.get("mongodb-atlas").db("tinyslack").collection("users");
   return collection.deleteOne({userId: context.user.id, username: context.user.data.email, displayName}).then((r) => {
      return r;
    }).catch((err) => {
      console.error(err);
    });

};