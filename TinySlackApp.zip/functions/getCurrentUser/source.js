exports = function(ctx){
  if (!ctx)
    ctx = context;
  const mongodb = ctx.services.get("mongodb-atlas");
  const dbname = ctx.values.get("DATABASE_NAME");
  const collection = mongodb.db(dbname).collection("users");
  const uid = ctx.user.id;

  return collection.count({ userId: uid }).then(c => { 
    if (c === 0)
      return collection.insertOne({ userId: uid, email: ctx.user.data.email, username: ctx.user.data.email });
  }).then(result => {
    return collection.findOne({ userId: uid });
  });
};