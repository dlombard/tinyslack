exports = async function(args){
    let currentUser = await context.functions.execute("getCurrentUser", context);
    
    let {channelId,channelName, message} = args;
    if (!channelName)
      return { success: false, message: "No Channel name provided" };
    if (!message)
      return { success: false, message: "No message provided" };

    //Accessing a mongodb service:
    const mongodb = context.services.get("mongodb-atlas");
    const dbname = context.values.get("DATABASE_NAME");
    const collection = mongodb.db(dbname).collection("messages");

    try{
      var r = collection.insertOne({ channelName, channelId, username: currentUser.username , message });
      console.log("Added message Id " + r.insertedId);
      return { success: true, message: "Message successfully added" };
    }catch(e){
      return e;
    }
}