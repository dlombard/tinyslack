exports = function(arg){
 let name = arg.name;
  let status = arg.status;
  let desc = arg.description;
  
  if (!name)
    return { success: false, message: "No channel name specified" };
  
  const mongodb = context.services.get("mongodb-atlas");
  const dbname = context.values.get("DATABASE_NAME");
  const collection = mongodb.db(dbname).collection("channels");

  return collection
    .deleteOne({name: name, status: status, description: desc})
    .then(result => {
      const { deletedId } = result;
      console.log("Removed Channel with Id " + deletedId);
      return { success: true, message: "Channel successfully removed" };
   });

};