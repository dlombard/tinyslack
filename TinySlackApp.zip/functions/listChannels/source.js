exports = async (arg) => {
  
  const mongodb = context.services.get("mongodb-atlas");
  const dbname = context.values.get("DATABASE_NAME");
  
  /*const collection = mongodb.db(dbname).collection("users");

  var channels = []
  
  var uid = context.user.id;
  var count = await collection.count({ userId: uid });
  if(count > 0)
     return await collection.findOne({ userId: uid }, {channels: 1})
  */
  
  const collection = mongodb.db(dbname).collection("channels");
  try{
    var channels =  await collection.find().toArray();
    return channels;
  }catch(e){
    return e;
  }


};