exports = function(arg){
  const {name, insertedId} = arg[0];
  console.log(JSON.stringify(arg));
  if (!name)
    return { success: false, message: "Missing channel name" };
  
  const mongodb = context.services.get("mongodb-atlas");
  const dbname = context.values.get("DATABASE_NAME");
  const collection = mongodb.db(dbname).collection("users");


  return collection.updateOne({ userId: context.user.id }, {'$addToSet': {"channels": {"channelName": name, "channelId":insertedId.toString(),  "lastMessageIdRead": null}}}).then(r => {
    console.log(JSON.stringify(r))
    return r;
  }).catch((err) => {
    console.error(err);
    return err;
  });
    
};