exports = function(arg){
  //arg = { name: "jmftest1" }
  const {name, description, isPrivate} = arg;
  
  if (!name)
    return { success: false, message: "No channel name specified" };
  
  const mongodb = context.services.get("mongodb-atlas");
  const dbname = context.values.get("DATABASE_NAME");
  const collection = mongodb.db(dbname).collection("channels");

  return collection
    .insertOne({ name, isPrivate, description, userId: context.user.id })
    .then(result => {
      const { insertedId } = result;
       console.log("Created Collection with Id " + insertedId);
      return context.functions.execute("subscribeChannel", [{name, insertedId}]);
   }).then(x => {
     console.log(JSON.stringify(x))
      return { success: true, message: "Channel successfully created" };
   });
};