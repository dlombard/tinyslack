exports = function(arg){
    var displayName = context.user.data.email;
    if(arg.displayName){
      displayName = arg.displayName;
    }
    
   var collection = context.services.get("mongodb-atlas").db("tinyslack").collection("users");
   return collection.insertOne({userId: context.user.id, username: context.user.data.email, displayName}).then((r) => {
       return { success: true};
    }).catch((err) => {
      console.error(err);
    });

};